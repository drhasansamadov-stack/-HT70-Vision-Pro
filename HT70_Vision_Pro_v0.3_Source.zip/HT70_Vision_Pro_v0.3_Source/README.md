# HT70 Vision Pro v0.3.0-beta (independent Android project)

Experimental, independent viewer for HT70-LRF. **Not** a modified Sytong Outdoor APK.

- Own Android package ID: `com.hasan.ht70visionpro` (official: `com.szsytong.sytong`). Does not remove, update, access the private app data of, or replace Sytong Outdoor.
- **LIVE**: RTSP H.264 RTP/UDP video at the candidate `rtsp://192.168.1.1:554/h264/channel=0/video/`. Also probes `.254` and `192.168.3.15` if the camera uses one of those. Wi-Fi route binding is important because Android may put mobile data as its default route when the optics Wi-Fi has no Internet.
- **REC / STOP REC**: captures original *received* H.264 access units without re-encoding to video-only MP4 (no audio unless added in a future version). Waits for next keyframe to begin. Source RTP timestamps determine playback speed. New Android versions: `Movies/HT70VisionPro` in phone gallery; old Android versions: app-specific Movies directory. Not inventing/upscaling resolution, FPS, or video bit rate. Video quality can never exceed the Wi-Fi stream or restore lost packets. Does not alter device encoder settings.
- **SD FILES**: separate read-only file transfer screen. Attempts to list HTTP directory indexes at `/DCIM/MOVIE/`, `/DCIM/PHOTO/`, `/IPCAM/MOVIE/`, `/IPCAM/PHOTO/`. Supports direct filename/path entry if the exact path is known. Streaming binary files with progress, measured transfer speed, HTTP Range resume if the device honors Range, and saves originals into public Pictures/Movies on Android 10+. The camera's proprietary directory listing protocol **is not yet reverse-mapped**; many firmware versions will not expose HTTP directory indexes, so listing may be empty until the protocol is implemented. Devices may not support HTTP Range and may require restarting transfer. No deletion from SD.
- **FULL**: landscape immersive player preserving video aspect ratio, pinch zoom.
- **Transport**: UDP jitter-buffer presets, stream FPS/loss/jitter and reconnection. No guarantee of eliminating RF interference or low camera Wi-Fi throughput.

## Safety and testing

This has not been tested on the physical HT70. Only use with your own device. It does not write camera firmware or operate reticles, ballistics, or aiming. This beta does not include bird/animal tracking. Test in order: HT70 Wi-Fi connection with mobile-data-independent Wi-Fi route, CONNECT/Live, REC for 15 seconds, MP4 playback in phone gallery, SD FILES.

A previously observed screenshot showed `HT70 • TAPILMADI` and FPS 0: **recording cannot work until live RTSP connectivity succeeds**.

## Build

Upload this project's ZIP archive to the repository and update existing `.github/workflows/build-apk.yml` to refer to `HT70_Vision_Pro_v0.3_Source.zip` (instead of `HT70_Vision_Pro_v0.2_Source.zip`) in the unzip and CD commands. The workflow must use `android-actions/setup-android@v4`. GitHub Actions produces a debug APK in its artifacts; a success result means it compiled, not that it was tested with the camera.

Do **not** upload the manufacturer's firmware or original APK, device passwords, or private camera footage into a public repository.

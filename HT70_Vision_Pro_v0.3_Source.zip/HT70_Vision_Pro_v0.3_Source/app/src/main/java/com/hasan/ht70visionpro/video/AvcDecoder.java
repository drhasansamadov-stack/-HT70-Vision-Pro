package com.hasan.ht70visionpro.video;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Build;
import android.view.Surface;
import com.hasan.ht70visionpro.StreamStats;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;

public final class AvcDecoder {
    private static final class AU { final byte[] d; final long ts; final boolean key; AU(byte[]d,long ts,boolean k){this.d=d;this.ts=ts;this.key=k;} }
    private final ArrayBlockingQueue<AU> q = new ArrayBlockingQueue<>(12);
    private final Surface surface;
    private final StreamStats stats;
    private volatile boolean running;
    private MediaCodec codec;
    private Thread thread;
    private long firstRtpTs = -1;
    private long baseUs = 0;

    public AvcDecoder(Surface surface, StreamStats stats){this.surface=surface;this.stats=stats;}

    public synchronized void start(int width,int height,byte[] sps,byte[] pps) throws Exception {
        stop();
        codec=MediaCodec.createDecoderByType("video/avc");
        MediaFormat f=MediaFormat.createVideoFormat("video/avc",width,height);
        if(sps!=null) f.setByteBuffer("csd-0",ByteBuffer.wrap(withStart(sps)));
        if(pps!=null) f.setByteBuffer("csd-1",ByteBuffer.wrap(withStart(pps)));
        if(Build.VERSION.SDK_INT>=30) f.setInteger("low-latency",1);
        codec.configure(f,surface,null,0); codec.start();
        running=true; firstRtpTs=-1; baseUs=System.nanoTime()/1000;
        thread=new Thread(this::loop,"HT70-Decoder"); thread.start();
    }

    public void queue(byte[] data,long rtpTimestamp,boolean key){
        if(!running)return;
        if(!q.offer(new AU(data,rtpTimestamp,key))){ q.poll(); q.offer(new AU(data,rtpTimestamp,key)); stats.decoderDrops.incrementAndGet(); }
    }

    private void loop(){
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        try{
            while(running){
                AU au=q.poll();
                if(au!=null){
                    int idx=codec.dequeueInputBuffer(5000);
                    if(idx>=0){ ByteBuffer b=codec.getInputBuffer(idx); if(b!=null){ b.clear(); if(au.d.length<=b.remaining()){ b.put(au.d); if(firstRtpTs<0) firstRtpTs=au.ts; long delta=(au.ts-firstRtpTs)&0xFFFFFFFFL; long pts=baseUs+(delta*1000000L/90000L); codec.queueInputBuffer(idx,0,au.d.length,pts,0);} else {codec.queueInputBuffer(idx,0,0,0,0);stats.decoderDrops.incrementAndGet();}} }
                }
                int out;
                while((out=codec.dequeueOutputBuffer(info,0))>=0){ codec.releaseOutputBuffer(out,true); stats.onFrame(); }
                if(au==null) Thread.sleep(2);
            }
        }catch(Throwable ignored){}
    }

    public synchronized void stop(){
        running=false; q.clear();
        if(thread!=null){ try{thread.join(300);}catch(Exception ignored){} thread=null; }
        if(codec!=null){ try{codec.stop();}catch(Exception ignored){} try{codec.release();}catch(Exception ignored){} codec=null; }
    }
    private static byte[] withStart(byte[] n){byte[]o=new byte[n.length+4];o[2]=0;o[3]=1;System.arraycopy(n,0,o,4,n.length);return o;}
}

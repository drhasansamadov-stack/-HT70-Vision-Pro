package com.hasan.ht70visionpro.video;

import com.hasan.ht70visionpro.net.RtpPacket;
import java.io.ByteArrayOutputStream;

public final class H264Depacketizer {
    public interface Listener { void onAccessUnit(byte[] data, long rtpTimestamp, boolean keyFrame); }
    private final Listener listener;
    private ByteArrayOutputStream au = new ByteArrayOutputStream(256 * 1024);
    private long currentTs = -1;
    private boolean key = false;
    private boolean damaged = false;

    public H264Depacketizer(Listener listener) { this.listener = listener; }

    public void onPacket(RtpPacket p) {
        if (p.payload.length < 1) return;
        if (currentTs != -1 && p.timestamp != currentTs && au.size() > 0) emit(false);
        currentTs = p.timestamp;
        int type = p.payload[0] & 0x1F;
        if (type >= 1 && type <= 23) {
            writeStartCode();
            au.write(p.payload, 0, p.payload.length);
            if (type == 5) key = true;
        } else if (type == 24) { // STAP-A
            int off = 1;
            while (off + 2 <= p.payload.length) {
                int n = ((p.payload[off] & 0xFF) << 8) | (p.payload[off + 1] & 0xFF);
                off += 2;
                if (n <= 0 || off + n > p.payload.length) { damaged = true; break; }
                int nt = p.payload[off] & 0x1F;
                writeStartCode(); au.write(p.payload, off, n);
                if (nt == 5) key = true;
                off += n;
            }
        } else if (type == 28) { // FU-A
            if (p.payload.length < 2) return;
            int fuIndicator = p.payload[0] & 0xFF;
            int fuHeader = p.payload[1] & 0xFF;
            boolean start = (fuHeader & 0x80) != 0;
            int originalType = fuHeader & 0x1F;
            if (start) {
                writeStartCode();
                int reconstructed = (fuIndicator & 0xE0) | originalType;
                au.write(reconstructed);
                if (originalType == 5) key = true;
            }
            if (p.payload.length > 2) au.write(p.payload, 2, p.payload.length - 2);
        }
        if (p.marker) emit(true);
    }

    public void onPacketGap() { damaged = true; }

    public void prependConfig(byte[] sps, byte[] pps) {
        if (sps != null) { writeStartCode(); au.write(sps, 0, sps.length); }
        if (pps != null) { writeStartCode(); au.write(pps, 0, pps.length); }
    }

    private void writeStartCode() { au.write(0); au.write(0); au.write(0); au.write(1); }

    private void emit(boolean marker) {
        if (au.size() > 0 && !damaged) listener.onAccessUnit(au.toByteArray(), currentTs, key);
        au.reset(); key = false; damaged = false;
        if (marker) currentTs = -1;
    }
}

package com.hasan.ht70visionpro.files;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.List;

public final class DeviceFilesActivity extends Activity {
    private TextView info;private LinearLayout entries;private final Handler ui=new Handler(Looper.getMainLooper());
    private DeviceFileService service;
    private volatile boolean busy=false;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        service=new DeviceFileService(this,getIntent().getStringExtra("host"));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,12,20,12);root.setBackgroundColor(Color.rgb(10,15,13));
        TextView title=label("HT70 • SD FILES",22);title.setTextColor(0xFF32E47D);root.addView(title);
        info=label("Cihaz: "+service.getHost()+" • SD yalnız oxunur",14);root.addView(info);
        TextView warning=label("HTTP qovluq siyahısı bütün HT70 firmware-lərində açıq olmaya bilər. Fayl siyahısı gəlməzsə, xüsusi protokol hələ uyğunlaşdırılmalıdır.",13);
        root.addView(warning);
        LinearLayout actions=new LinearLayout(this);root.addView(actions);
        Button refresh=button("REFRESH");actions.addView(refresh); refresh.setOnClickListener(v->refresh());
        Button direct=button("FILE PATH");actions.addView(direct);direct.setOnClickListener(v->manual());
        Button back=button("BACK");actions.addView(back);back.setOnClickListener(v->finish());
        ScrollView scroll=new ScrollView(this);entries=new LinearLayout(this);entries.setOrientation(LinearLayout.VERTICAL);scroll.addView(entries);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        refresh();
    }
    private void refresh(){if(busy)return;busy=true;info.setText("SD siyahısı sorğulanır…");entries.removeAllViews();
        new Thread(()->{
            List<DeviceFileService.Item> list=null;String err=null;
            try{list=service.tryReadHttpIndexes();}catch(Exception e){err=e.getMessage();}
            final List<DeviceFileService.Item> result=list;final String error=err;
            ui.post(()->{busy=false;
                if(error!=null){info.setText("Siyahı xətası: "+error);return;}
                if(result==null||result.isEmpty()){
                    info.setText("HTTP qovluq siyahısı açılmadı. Fayl adını bilirsinizsə FILE PATH seçin. Digər fayllar üçün cihazın öz siyahı protokolu lazımdır.");
                }else{info.setText(result.size()+" fayl aşkarlandı • toxunun: telefona yüklə");for(DeviceFileService.Item item:result){Button b=button(item.category+" • "+item.filename);entries.addView(b);b.setOnClickListener(v->confirm(item));}}
            });
        },"HT70-SD-List").start();
    }
    private void manual(){EditText input=new EditText(this);input.setSingleLine(true);input.setText("/DCIM/MOVIE/");input.setTextColor(Color.BLACK);
        new AlertDialog.Builder(this).setTitle("Cihazda fayl yolu")
            .setMessage("Nümunə: /DCIM/MOVIE/VIDEO001.MP4. Dəqiq fayl adı olmalıdır.")
            .setView(input).setNegativeButton("LƏĞV",null).setPositiveButton("DOWNLOAD",(d,w)->{
                try{confirm(service.manualPath(input.getText().toString()));}catch(Exception e){info.setText(e.getMessage());}
            }).show();
    }
    private void confirm(DeviceFileService.Item item){if(busy)return;
        new AlertDialog.Builder(this).setTitle("Telefona yüklə?").setMessage(item.filename+"\nOrijinal cihaz faylı, dəyişdirilmədən köçürüləcək.")
            .setNegativeButton("LƏĞV",null).setPositiveButton("DOWNLOAD",(d,w)->download(item)).show();
    }
    private void download(DeviceFileService.Item item){if(busy)return;busy=true;info.setText("DOWNLOAD: "+item.filename);
        new Thread(()->{
            try{service.download(item,message->ui.post(()->info.setText(message)));}
            catch(Exception e){ui.post(()->info.setText("Transfer xətası: "+e.getMessage()));}
            finally{ui.post(()->busy=false);}
        },"HT70-Download").start();
    }
    private TextView label(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.WHITE);v.setPadding(8,9,8,9);return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF174D2A));return b;}
}

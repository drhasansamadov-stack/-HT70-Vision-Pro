package com.hasan.ht70visionpro.net;

import com.hasan.ht70visionpro.StreamStats;
import java.util.HashMap;
import java.util.Map;

public final class AdaptiveJitterBuffer {
    private final Map<Integer, RtpPacket> packets = new HashMap<>();
    private final StreamStats stats;
    private int expected = -1;
    private long firstArrivalMs = -1;
    private long gapSinceMs = -1;
    private volatile int targetDelayMs = 100;
    private boolean started = false;

    public AdaptiveJitterBuffer(StreamStats stats) { this.stats = stats; }

    public synchronized void setTargetDelayMs(int ms) {
        targetDelayMs = Math.max(20, Math.min(350, ms));
    }

    public synchronized void reset() {
        packets.clear(); expected = -1; firstArrivalMs = -1; gapSinceMs = -1; started = false;
    }

    public synchronized void offer(RtpPacket p) {
        stats.packets.incrementAndGet();
        stats.lastPacketAtMs = p.arrivalMs;
        if (firstArrivalMs < 0) firstArrivalMs = p.arrivalMs;
        if (expected < 0) expected = p.sequence;
        packets.put(p.sequence, p);
        if (packets.size() > 512) {
            packets.clear(); expected = p.sequence; started = false; firstArrivalMs = p.arrivalMs;
        }
    }

    public synchronized RtpPacket poll(long nowMs) {
        if (expected < 0) return null;
        if (!started) {
            if (nowMs - firstArrivalMs < targetDelayMs) return null;
            started = true;
        }
        RtpPacket p = packets.remove(expected);
        if (p != null) {
            expected = (expected + 1) & 0xFFFF;
            gapSinceMs = -1;
            return p;
        }
        if (gapSinceMs < 0) gapSinceMs = nowMs;
        int gapWait = Math.max(12, Math.min(60, targetDelayMs / 2));
        if (nowMs - gapSinceMs >= gapWait) {
            stats.lost.incrementAndGet();
            expected = (expected + 1) & 0xFFFF;
            gapSinceMs = nowMs;
        }
        return null;
    }
}

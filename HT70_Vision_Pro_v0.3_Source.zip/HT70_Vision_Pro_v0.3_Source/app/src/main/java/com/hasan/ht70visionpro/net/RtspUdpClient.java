package com.hasan.ht70visionpro.net;

import android.os.Process;
import android.util.Base64;
import com.hasan.ht70visionpro.StreamStats;
import com.hasan.ht70visionpro.video.H264Depacketizer;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RtspUdpClient {
    public interface Callback {
        void onStatus(String s);
        void onVideoConfig(byte[] sps, byte[] pps, int width, int height);
        void onAccessUnit(byte[] data,long ts,boolean key);
        void onFatal(String reason);
    }

    private final String host; private final int port; private final String path;
    private final Callback cb; private final StreamStats stats;
    private volatile boolean running; private Socket rtsp; private DatagramSocket rtp,rtcp;
    private Thread netThread, playoutThread; private final AdaptiveJitterBuffer jitter;
    private H264Depacketizer dep;
    private int cseq=1; private String session=""; private int delayMs=100;
    private long lastTransit=Long.MIN_VALUE; private double jitterTs=0;

    public RtspUdpClient(String host,int port,String path,Callback cb,StreamStats stats){
        this.host=host;this.port=port;this.path=path;this.cb=cb;this.stats=stats;this.jitter=new AdaptiveJitterBuffer(stats);
        dep=new H264Depacketizer(cb::onAccessUnit);
    }
    public void setBufferMs(int ms){delayMs=ms;jitter.setTargetDelayMs(ms);}

    public void start(){ if(running)return; running=true; netThread=new Thread(this::run,"HT70-RTSP"); netThread.start(); }
    public void stop(){running=false; closeAll(); if(playoutThread!=null)playoutThread.interrupt();}

    private void run(){
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
        try{
            cb.onStatus("RTSP qoşulur…");
            rtsp=new Socket(); rtsp.connect(new InetSocketAddress(host,port),2500); rtsp.setSoTimeout(5000); rtsp.setTcpNoDelay(true);
            String base="rtsp://"+host+":"+port+path;
            Response desc=request("DESCRIBE",base,"Accept: application/sdp\r\n",null);
            if(desc.code!=200) throw new IOException("DESCRIBE "+desc.code);
            Sdp s=parseSdp(desc.body,base,desc.headers.get("content-base"));
            cb.onVideoConfig(s.sps,s.pps,s.width,s.height);
            int[] ports=openUdpPair();
            String transport="Transport: RTP/AVP/UDP;unicast;client_port="+ports[0]+"-"+ports[1]+"\r\n";
            Response setup=request("SETUP",s.controlUrl,transport,null);
            if(setup.code!=200) throw new IOException("SETUP "+setup.code);
            String sh=setup.headers.get("session"); if(sh!=null) session=sh.split(";",2)[0].trim();
            Response play=request("PLAY",base,"Range: npt=0.000-\r\n",null);
            if(play.code!=200) throw new IOException("PLAY "+play.code);
            cb.onStatus("CANLI • UDP • buffer "+delayMs+" ms");
            startPlayout(); receiveRtp();
        }catch(Throwable t){ if(running) cb.onFatal(t.getClass().getSimpleName()+": "+t.getMessage()); }
        finally{closeAll();}
    }

    private void receiveRtp() throws Exception {
        byte[] buf=new byte[65535]; DatagramPacket dp=new DatagramPacket(buf,buf.length);
        rtp.setSoTimeout(1500);
        while(running){
            try{
                dp.setLength(buf.length); rtp.receive(dp); long now=System.currentTimeMillis();
                RtpPacket p=RtpPacket.parse(dp.getData(),dp.getLength(),now); if(p==null)continue;
                long arrival90=now*90L; long transit=arrival90-p.timestamp;
                if(lastTransit!=Long.MIN_VALUE){ long d=Math.abs(transit-lastTransit); jitterTs += (d-jitterTs)/16.0; stats.jitterMs=jitterTs/90.0; }
                lastTransit=transit; jitter.offer(p);
            }catch(SocketTimeoutException e){ if(running) throw new IOException("video paketləri dayanıb"); }
        }
    }

    private void startPlayout(){
        playoutThread=new Thread(() -> { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY); int lastSeq=-1; while(running){
            RtpPacket p=jitter.poll(System.currentTimeMillis());
            if(p!=null){ if(lastSeq>=0 && (((lastSeq+1)&0xFFFF)!=p.sequence)) dep.onPacketGap(); dep.onPacket(p); lastSeq=p.sequence; }
            else try{Thread.sleep(1);}catch(InterruptedException ignored){}
        }},"HT70-Jitter"); playoutThread.start();
    }

    private int[] openUdpPair() throws Exception {
        Random r=new Random();
        for(int i=0;i<60;i++){
            int p=42000 + r.nextInt(10000); p &= ~1;
            DatagramSocket a=null,b=null;
            try{ a=new DatagramSocket(null); a.setReuseAddress(false); a.setReceiveBufferSize(4*1024*1024); a.bind(new InetSocketAddress(p));
                b=new DatagramSocket(null); b.setReuseAddress(false); b.bind(new InetSocketAddress(p+1)); rtp=a;rtcp=b; return new int[]{p,p+1};
            }catch(Exception e){ if(a!=null)a.close(); if(b!=null)b.close(); }
        }
        throw new IOException("UDP port açıla bilmədi");
    }

    private Response request(String method,String url,String extra,String body) throws Exception {
        StringBuilder s=new StringBuilder(); s.append(method).append(' ').append(url).append(" RTSP/1.0\r\nCSeq: ").append(cseq++).append("\r\nUser-Agent: HT70-VisionPro/0.2\r\n");
        if(!session.isEmpty())s.append("Session: ").append(session).append("\r\n"); if(extra!=null)s.append(extra);
        byte[] bb=body==null?null:body.getBytes(StandardCharsets.UTF_8); if(bb!=null)s.append("Content-Length: ").append(bb.length).append("\r\n"); s.append("\r\n");
        OutputStream o=rtsp.getOutputStream(); o.write(s.toString().getBytes(StandardCharsets.US_ASCII)); if(bb!=null)o.write(bb); o.flush(); return readResponse(rtsp.getInputStream());
    }

    private Response readResponse(InputStream in) throws Exception {
        ByteArrayOutputStream h=new ByteArrayOutputStream(); int state=0,c;
        while((c=in.read())!=-1){h.write(c); if(state==0&&c=='\r')state=1;else if(state==1&&c=='\n')state=2;else if(state==2&&c=='\r')state=3;else if(state==3&&c=='\n')break;else state=0;}
        String hs=h.toString("US-ASCII"); String[] lines=hs.split("\r\n"); if(lines.length==0)throw new IOException("boş RTSP cavabı");
        int code=Integer.parseInt(lines[0].split(" ")[1]); Map<String,String> headers=new HashMap<>(); int len=0;
        for(int i=1;i<lines.length;i++){int k=lines[i].indexOf(':');if(k>0){String key=lines[i].substring(0,k).trim().toLowerCase(Locale.US);String val=lines[i].substring(k+1).trim();headers.put(key,val);if(key.equals("content-length"))try{len=Integer.parseInt(val);}catch(Exception ignored){}}}
        byte[] b=new byte[len]; int off=0; while(off<len){int n=in.read(b,off,len-off);if(n<0)break;off+=n;} return new Response(code,headers,new String(b,0,off,StandardCharsets.UTF_8));
    }

    private Sdp parseSdp(String body,String requestUrl,String contentBase){
        String base=(contentBase!=null&&!contentBase.isEmpty())?contentBase:requestUrl;
        String control=null; byte[]sps=null,pps=null; int width=1920,height=1080;
        for(String line:body.split("[\\r\\n]+")){
            line=line.trim();
            if(line.startsWith("a=control:") && !line.endsWith("*")){String v=line.substring(10).trim(); if(v.startsWith("rtsp://"))control=v; else {if(!base.endsWith("/"))base+="/";control=base+v;}}
            if(line.startsWith("a=fmtp:") && line.contains("sprop-parameter-sets=")){
                Matcher m=Pattern.compile("sprop-parameter-sets=([^;,]+),([^;\\r\\n]+)").matcher(line); if(m.find())try{sps=Base64.decode(m.group(1),Base64.DEFAULT);pps=Base64.decode(m.group(2),Base64.DEFAULT);}catch(Exception ignored){}
            }
            Matcher fm=Pattern.compile("a=framesize:\\d+\\s+(\\d+)-(\\d+)").matcher(line); if(fm.find()){width=Integer.parseInt(fm.group(1));height=Integer.parseInt(fm.group(2));}
        }
        if(control==null){ if(!base.endsWith("/"))base+="/";control=base+"trackID=0"; }
        if(sps!=null){int[] wh=com.hasan.ht70visionpro.video.SpsParser.parseSize(sps); if(wh[0]>0&&wh[1]>0){width=wh[0];height=wh[1];}}
        return new Sdp(control,sps,pps,width,height);
    }

    private void closeAll(){ try{if(rtp!=null)rtp.close();}catch(Exception ignored){} try{if(rtcp!=null)rtcp.close();}catch(Exception ignored){} try{if(rtsp!=null)rtsp.close();}catch(Exception ignored){} rtp=null;rtcp=null;rtsp=null;jitter.reset(); }
    private static final class Response{final int code;final Map<String,String>headers;final String body;Response(int c,Map<String,String>h,String b){code=c;headers=h;body=b;}}
    private static final class Sdp{final String controlUrl;final byte[]sps,pps;final int width,height;Sdp(String c,byte[]s,byte[]p,int w,int h){controlUrl=c;sps=s;pps=p;width=w;height=h;}}
}

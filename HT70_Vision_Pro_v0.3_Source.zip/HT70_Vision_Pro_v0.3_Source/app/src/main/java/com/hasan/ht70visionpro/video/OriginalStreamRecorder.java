package com.hasan.ht70visionpro.video;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaMuxer;
import android.media.MediaFormat;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Video-only, passthrough H.264 -> MP4. No re-encoding or synthetic FPS. */
public final class OriginalStreamRecorder {
    public interface Listener { void onRecordingFinished(String detail, boolean success); }
    private static final class AccessUnit {
        final byte[] data; final long rtpTs; final boolean key;
        AccessUnit(byte[] data,long ts, boolean key){this.data=data;this.rtpTs=ts;this.key=key;}
    }
    private final ArrayBlockingQueue<AccessUnit> queue = new ArrayBlockingQueue<>(160);
    private final Context context; private final Listener listener;
    private volatile boolean recording, accepting;
    private Thread writer;
    private int width, height; private byte[] sps, pps;
    private long dropped=0; private long saved=0;

    public OriginalStreamRecorder(Context context,Listener listener){this.context=context.getApplicationContext();this.listener=listener;}
    public synchronized boolean isRecording(){return accepting;}
    public synchronized boolean isBusy(){return recording;}
    public synchronized void setVideoFormat(byte[] sps,byte[] pps,int w,int h){
        // Never modify active MP4 format mid-recording.
        if(recording)return;
        this.sps=sps == null ? null : sps.clone(); this.pps=pps == null ? null : pps.clone();
        this.width=w;this.height=h;
    }
    public synchronized void learnParameterSets(byte[] au) {
        if ((sps!=null && pps!=null)||au==null)return;
        for(int i=0;i+4<au.length;){
            int start=findStart(au,i);if(start<0)break;
            int prefix=(au[start+2]==1)?3:4;
            int nal=start+prefix;
            int next=findStart(au,nal+1);if(next<0)next=au.length;
            int type=au[nal]&31;
            if(next>nal && next-nal<256){
                if(type==7 && sps==null){sps=new byte[next-nal];System.arraycopy(au,nal,sps,0,sps.length);}
                if(type==8 && pps==null){pps=new byte[next-nal];System.arraycopy(au,nal,pps,0,pps.length);}
            }
            i=next;
        }
    }
    private static int findStart(byte[] a,int from){
        for(int i=from;i+3<a.length;i++){
            if(a[i]==0 && a[i+1]==0 && (a[i+2]==1 || (a[i+2]==0 && a[i+3]==1)))return i;
        }
        return -1;
    }
    public synchronized String start(){
        if(recording)return "Artıq yazılır";
        if(sps==null || pps==null || sps.length==0 || pps.length==0 || width<=0 || height<=0)
            return "H.264 SPS/PPS alınmayıb; cihazın canlı axınına qoşulun";
        queue.clear();dropped=0;saved=0; recording=true;accepting=true;
        final byte[] localSps=sps.clone(),localPps=pps.clone(); final int w=width,h=height;
        writer=new Thread(()->writeLoop(localSps,localPps,w,h),"HT70-MP4-Muxer");writer.start();
        return null;
    }
    public void offer(byte[] frame,long rtpTimestamp,boolean isKey){
        if(!accepting || frame==null)return;
        if(!queue.offer(new AccessUnit(frame,rtpTimestamp,isKey))) {
            // Disk cannot keep up: do not block the RTP receiver and cause more stream loss.
            queue.poll(); dropped++; queue.offer(new AccessUnit(frame,rtpTimestamp,isKey));
        }
    }
    public synchronized void stop(){accepting=false;}

    private void writeLoop(byte[] sps,byte[] pps,int w,int h){
        MediaMuxer muxer=null; ParcelFileDescriptor fd=null; Uri savedUri=null;File localFile=null;
        boolean started=false; String result="";boolean ok=false;
        ContentResolver resolver=context.getContentResolver();
        String filename="HT70_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
        try{
            if(Build.VERSION.SDK_INT>=29){
                ContentValues cv=new ContentValues();cv.put(MediaStore.Video.Media.DISPLAY_NAME,filename);
                cv.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
                cv.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/HT70VisionPro");
                cv.put(MediaStore.Video.Media.IS_PENDING,1);
                savedUri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,cv);
                if(savedUri==null)throw new Exception("MediaStore yaradıla bilmədi");
                fd=resolver.openFileDescriptor(savedUri,"w");
                if(fd==null)throw new Exception("Fayl descriptoru alınmadı");
                muxer=new MediaMuxer(fd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            }else{
                File dir=new File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),"HT70VisionPro");
                if(!dir.exists()&&!dir.mkdirs())throw new Exception("Video qovluğu yaradılmadı");
                localFile=new File(dir,filename);
                muxer=new MediaMuxer(localFile.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            }
            MediaFormat format=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,w,h);
            format.setByteBuffer("csd-0",ByteBuffer.wrap(startCode(sps)));
            format.setByteBuffer("csd-1",ByteBuffer.wrap(startCode(pps)));
            // Do not set an invented frame rate/bit rate: preserve source timestamps and compressed bytes.
            int track=muxer.addTrack(format);muxer.start();started=true;
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long firstTs=-1,lastUs=-1;
            while(accepting || !queue.isEmpty()){
                AccessUnit unit=queue.poll(250,TimeUnit.MILLISECONDS);if(unit==null)continue;
                if(firstTs<0){if(!unit.key)continue;firstTs=unit.rtpTs;}
                long delta=(unit.rtpTs-firstTs)&0xFFFFFFFFL;
                long pts=delta*1000000L/90000L;
                if(pts<=lastUs)pts=lastUs+1;
                // Limit pathological gaps after long network stalls: prefer honest timestamps.
                info.set(0,unit.data.length,pts,unit.key?MediaCodec.BUFFER_FLAG_KEY_FRAME:0);
                muxer.writeSampleData(track,ByteBuffer.wrap(unit.data),info);
                lastUs=pts;saved++;
            }
            if(saved==0)throw new Exception("Açar kadr alınmadı; video saxlanmadı");
            ok=true;
            result="Video saxlandı: "+filename+" ("+saved+" kadr, diskə yetişməyən "+dropped+")";
        }catch(Exception e){result="Video yazma xətası: "+e.getMessage();}
        finally{
            if(muxer!=null){if(started)try{muxer.stop();}catch(Exception e){ok=false;result="MP4 yekunlaşdırıla bilmədi: "+e.getMessage();}try{muxer.release();}catch(Exception ignored){}}
            if(fd!=null)try{fd.close();}catch(Exception ignored){}
            if(savedUri!=null){
                if(ok){ ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.IS_PENDING,0);try{resolver.update(savedUri,values,null,null);}catch(Exception e){ok=false;result="Yayımlama xətası: "+e.getMessage();} }
                if(!ok)try{resolver.delete(savedUri,null,null);}catch(Exception ignored){}
            }
            if(localFile!=null){if(!ok)localFile.delete();else MediaScannerConnection.scanFile(context,new String[]{localFile.getAbsolutePath()},new String[]{"video/mp4"},null);}
            synchronized(this){recording=false;accepting=false;writer=null;}
            listener.onRecordingFinished(result,ok);
        }
    }
    private static byte[] startCode(byte[] nal){byte[] b=new byte[nal.length+4];b[3]=1;System.arraycopy(nal,0,b,4,nal.length);return b;}
}

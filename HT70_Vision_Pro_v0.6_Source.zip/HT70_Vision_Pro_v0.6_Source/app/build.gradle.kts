plugins { id("com.android.application") }

android {
    namespace = "com.hasan.ht70visionpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hasan.ht70visionpro"
        minSdk = 24
        targetSdk = 35
        versionCode = 6
        versionName = "0.6.0-media3-rtsp-diagnostic"
    }
}


dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
}

package com.hasan.ht70visionpro.files;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Read-only HTTP browse/download adapter; the firmware's proprietary directory-list command is not yet mapped. */
public final class DeviceFileService {
    public interface Progress { void update(String msg); }
    public static final class Item {
        public final String filename, url, category;
        public Item(String f,String url,String category){filename=f;this.url=url;this.category=category;}
    }
    private final String host;
    private final Context context;
    public DeviceFileService(Context c,String host){
        this.context=c.getApplicationContext();
        this.host=("192.168.1.254".equals(host)||"192.168.3.15".equals(host))?host:"192.168.1.1";
    }
    public String getHost(){return host;}
    private volatile String lastProbe="";
    public String getLastProbe(){return lastProbe;}
    public List<Item> tryReadHttpIndexes() throws IOException {
        List<Item> items=new ArrayList<>(); Set<String> seen=new HashSet<>();
        String[] bases={"/DCIM/MOVIE/","/DCIM/PHOTO/","/IPCAM/MOVIE/","/IPCAM/PHOTO/"};
        StringBuilder diagnostic=new StringBuilder();
        for(int port: new int[]{80,8192})for(String base:bases){
            HttpURLConnection conn=null;
            try{
                URL folderUrl=new URL("http",host,port,base);
                conn=(HttpURLConnection)folderUrl.openConnection();conn.setConnectTimeout(1600);conn.setReadTimeout(2000);
                conn.setInstanceFollowRedirects(false);conn.setRequestProperty("Accept","text/html,text/plain");
                int code=conn.getResponseCode();
                diagnostic.append(port).append(base).append(" HTTP ").append(code).append("; ");
                if(code!=200)continue;
                String type=conn.getContentType();if(type!=null && !type.toLowerCase(Locale.US).contains("text"))continue;
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];
                try(InputStream in=conn.getInputStream()){
                    int n;while((n=in.read(buf))>=0 && out.size()<800000){out.write(buf,0,n);}
                }
                String html=out.toString("UTF-8");
                Matcher m=Pattern.compile("(?i)href\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']").matcher(html);
                while(m.find())add(items,seen,folderUrl,m.group(1),base);
                // Some embedded HTTP servers provide one path per text line without HTML.
                if(items.isEmpty())for(String line:html.split("[\\r\\n]+")){
                    line=line.trim();if(line.matches("(?i)[a-zA-Z0-9_().%+-]+\\.(mp4|mov|avi|jpg|jpeg|png)"))add(items,seen,folderUrl,line,base);
                }
            }catch(IOException e){diagnostic.append(port).append(base).append(" ").append(e.getClass().getSimpleName()).append("; ");}
            finally{if(conn!=null)conn.disconnect();}
        }
        lastProbe=diagnostic.toString();
        return items;
    }
    private void add(List<Item> items,Set<String> seen,URL base,String ref,String category){
        try{
            if(ref.contains("?")||ref.contains("#")||ref.contains(".."))return;
            URL target=new URL(base,ref.replace("&amp;","&"));
            if(!"http".equals(target.getProtocol())||!host.equals(target.getHost())||(target.getPort()>0&&target.getPort()!=80&&target.getPort()!=8192))return;
            String path=target.getPath();
            if(!(path.startsWith("/DCIM/")||path.startsWith("/IPCAM/")))return;
            String name=URLDecoder.decode(path.substring(path.lastIndexOf('/')+1),"UTF-8");
            if(!name.matches("(?i)[a-zA-Z0-9_() .+%-]{1,125}\\.(mp4|mov|avi|jpg|jpeg|png)"))return;
            if(seen.add(target.toString()))items.add(new Item(name,target.toString(),category));
        }catch(Exception ignored){}
    }
    public Item manualPath(String path) throws Exception {
        path=path.trim();
        if(!path.startsWith("/DCIM/") && !path.startsWith("/IPCAM/"))throw new Exception("/DCIM/... və ya /IPCAM/... yolu daxil edin");
        if(path.contains("..")||path.contains("?")||path.contains("#"))throw new Exception("Yol düzgün deyil");
        String fn=path.substring(path.lastIndexOf('/')+1);
        if(!fn.matches("(?i)[a-zA-Z0-9_() .+%-]{1,125}\\.(mp4|mov|avi|jpg|jpeg|png)"))throw new Exception("Fayl adı düzgün deyil");
        String safePath=path.replace(" ","%20");
        return new Item(fn,"http://"+host+safePath,"Manual");
    }
    public void download(Item item,Progress progress) throws Exception {
        File dir=new File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"HT70VisionPro");
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("Müvəqqəti qovluq yaradıla bilmədi");
        File partial=new File(dir,item.filename+".part");
        long present=partial.exists()?partial.length():0;
        HttpURLConnection conn=null;
        try{
            conn=(HttpURLConnection)new URL(item.url).openConnection();
            conn.setConnectTimeout(5000);conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("Accept-Encoding","identity");
            if(present>0)conn.setRequestProperty("Range","bytes="+present+"-");
            int status=conn.getResponseCode();
            if(status!=200&&status!=206)throw new IOException("HTTP "+status+" — fayl linki dəstəklənmir");
            if(status==206){
                String range=conn.getHeaderField("Content-Range");
                if(range==null||!range.startsWith("bytes "+present+"-"))throw new IOException("Server Range cavabı uyğunsuzdur");
            }else if(present>0){present=0;} // Server did not honor resume; restart from byte 0.
            long total=conn.getContentLengthLong();if(total>0)total+=present;
            long count=present,lastBytes=count,lastTime=System.currentTimeMillis();
            try(InputStream in=conn.getInputStream();FileOutputStream out=new FileOutputStream(partial,present>0)){
                byte[] buf=new byte[128*1024];int n;
                while((n=in.read(buf))!=-1){out.write(buf,0,n);count+=n;long now=System.currentTimeMillis();
                    if(now-lastTime>=500){long speed=(count-lastBytes)*1000/Math.max(1,now-lastTime);
                        progress.update(item.filename+"  "+(total>0?(100*count/total)+"%  ":"")+String.format(Locale.US,"%.1f MB / %.1f MB/s",count/1048576.0,speed/1048576.0));
                        lastTime=now;lastBytes=count;}
                }
                out.getFD().sync();
            }
            if(total>0 && count!=total)throw new IOException("Yarımçıq transfer ("+count+"/"+total+"); davam etdirmək olar");
            if(!publish(partial,item.filename))throw new IOException("Telefon yaddaşına saxlama mümkün olmadı");
            if(!partial.delete())partial.deleteOnExit();
            progress.update("Saxlandı: "+item.filename+" ("+String.format(Locale.US,"%.1f",count/1048576.0)+" MB)");
        }finally{if(conn!=null)conn.disconnect();}
    }
    private boolean publish(File source,String filename) throws IOException {
        boolean video=filename.matches("(?i).*\\.(mp4|mov|avi)");
        boolean image=filename.matches("(?i).*\\.(jpg|jpeg|png)");
        if(Build.VERSION.SDK_INT>=29){
            Uri collection=video?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:image?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String folder=(video?Environment.DIRECTORY_MOVIES:image?Environment.DIRECTORY_PICTURES:Environment.DIRECTORY_DOWNLOADS)+"/HT70VisionPro";
            ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,filename);
            cv.put(MediaStore.MediaColumns.MIME_TYPE,video?"video/mp4":filename.toLowerCase(Locale.US).endsWith("png")?"image/png":"image/jpeg");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH,folder);cv.put(MediaStore.MediaColumns.IS_PENDING,1);
            ContentResolver r=context.getContentResolver();Uri uri=r.insert(collection,cv);if(uri==null)throw new IOException("MediaStore error");
            boolean done=false;
            try(InputStream in=new FileInputStream(source);OutputStream out=r.openOutputStream(uri)){
                if(out==null)throw new IOException("Yazma axını yoxdur");byte[]b=new byte[128*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                done=true;
            }finally{
                if(done){ContentValues commit=new ContentValues();commit.put(MediaStore.MediaColumns.IS_PENDING,0);r.update(uri,commit,null,null);}
                else r.delete(uri,null,null);
            }
            return true;
        }
        // API 24-28: app-specific external media folder, no broad storage permission needed.
        File destDir=new File(context.getExternalFilesDir(video?Environment.DIRECTORY_MOVIES:Environment.DIRECTORY_PICTURES),"HT70VisionPro");
        if(!destDir.exists()&&!destDir.mkdirs())throw new IOException("Yaddaş qovluğu yaradıla bilmədi");
        File dest=new File(destDir,filename);try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(dest)){
            byte[]b=new byte[131072];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
        }
        MediaScannerConnection.scanFile(context,new String[]{dest.getAbsolutePath()},null,null);
        return true;
    }
}

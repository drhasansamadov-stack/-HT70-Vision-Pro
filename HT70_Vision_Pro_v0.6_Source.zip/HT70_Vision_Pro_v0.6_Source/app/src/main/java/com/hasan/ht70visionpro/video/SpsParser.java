package com.hasan.ht70visionpro.video;

import java.io.ByteArrayOutputStream;

public final class SpsParser {
    public static int[] parseSize(byte[] spsNal) {
        try {
            byte[] rbsp = unescape(spsNal, 1);
            Bits b = new Bits(rbsp);
            int profile = b.readBits(8); b.readBits(8); b.readBits(8); b.ue();
            int chroma = 1;
            if (profile == 100 || profile == 110 || profile == 122 || profile == 244 || profile == 44 || profile == 83 || profile == 86 || profile == 118 || profile == 128 || profile == 138 || profile == 139 || profile == 134) {
                chroma = b.ue();
                if (chroma == 3) b.readBit();
                b.ue(); b.ue(); b.readBit();
                if (b.readBit() == 1) {
                    int count = chroma != 3 ? 8 : 12;
                    for (int i=0;i<count;i++) if (b.readBit()==1) skipScalingList(b, i < 6 ? 16 : 64);
                }
            }
            b.ue();
            int poc = b.ue();
            if (poc == 0) b.ue();
            else if (poc == 1) {
                b.readBit(); b.se(); b.se(); int n=b.ue(); for(int i=0;i<n;i++) b.se();
            }
            b.ue(); b.readBit();
            int picWidthMbsMinus1 = b.ue();
            int picHeightMapUnitsMinus1 = b.ue();
            int frameMbsOnly = b.readBit();
            if (frameMbsOnly == 0) b.readBit();
            b.readBit();
            int cropLeft=0,cropRight=0,cropTop=0,cropBottom=0;
            if (b.readBit()==1) { cropLeft=b.ue(); cropRight=b.ue(); cropTop=b.ue(); cropBottom=b.ue(); }
            int width = (picWidthMbsMinus1 + 1) * 16;
            int height = (2 - frameMbsOnly) * (picHeightMapUnitsMinus1 + 1) * 16;
            int subWidthC = chroma == 3 ? 1 : 2;
            int subHeightC = chroma == 1 ? 2 : 1;
            int cropUnitX = chroma == 0 ? 1 : subWidthC;
            int cropUnitY = chroma == 0 ? (2-frameMbsOnly) : subHeightC * (2-frameMbsOnly);
            width -= (cropLeft + cropRight) * cropUnitX;
            height -= (cropTop + cropBottom) * cropUnitY;
            return new int[]{width, height};
        } catch (Throwable t) { return new int[]{1920,1080}; }
    }

    private static byte[] unescape(byte[] in, int offset) {
        ByteArrayOutputStream o = new ByteArrayOutputStream(in.length);
        int zeros=0;
        for (int i=offset;i<in.length;i++) {
            int v=in[i]&0xFF;
            if (zeros>=2 && v==3) { zeros=0; continue; }
            o.write(v); if(v==0) zeros++; else zeros=0;
        }
        return o.toByteArray();
    }
    private static void skipScalingList(Bits b,int size){ int last=8,next=8; for(int j=0;j<size;j++){ if(next!=0) next=(last+b.se()+256)%256; last=next==0?last:next; } }
    private static final class Bits {
        final byte[] d; int p=0; Bits(byte[] d){this.d=d;}
        int readBit(){ return (d[p>>3] >> (7-(p++&7))) & 1; }
        int readBits(int n){ int v=0; for(int i=0;i<n;i++) v=(v<<1)|readBit(); return v; }
        int ue(){ int z=0; while(readBit()==0 && z<31) z++; int r=(1<<z)-1; if(z>0) r+=readBits(z); return r; }
        int se(){ int c=ue(); return ((c&1)==0)?-(c/2):((c+1)/2); }
    }
}

package com.hasan.ht70visionpro;

import java.util.concurrent.atomic.AtomicLong;

public final class StreamStats {
    public final AtomicLong packets = new AtomicLong();
    public final AtomicLong lost = new AtomicLong();
    public final AtomicLong frames = new AtomicLong();
    public final AtomicLong decoderDrops = new AtomicLong();
    public final AtomicLong reconnects = new AtomicLong();
    public volatile double jitterMs = 0.0;
    public volatile long lastPacketAtMs = 0;
    public volatile long lastFrameAtMs = 0;
    public volatile String decoderError="";
    private long fpsStart = System.currentTimeMillis();
    private long fpsFrames = 0;
    public volatile double fps = 0;

    public synchronized void onFrame() {
        frames.incrementAndGet();
        lastFrameAtMs = System.currentTimeMillis();
        fpsFrames++;
        long now = System.currentTimeMillis();
        long dt = now - fpsStart;
        if (dt >= 1000) {
            fps = fpsFrames * 1000.0 / dt;
            fpsFrames = 0;
            fpsStart = now;
        }
    }

    public double lossPercent() {
        long p = packets.get();
        long l = lost.get();
        long total = p + l;
        return total == 0 ? 0 : (100.0 * l / total);
    }
}

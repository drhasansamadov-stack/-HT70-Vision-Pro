package com.hasan.ht70visionpro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.rtsp.RtspMediaSource;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import com.hasan.ht70visionpro.files.DeviceFilesActivity;

/** v0.6: diagnostic RTSP test, independent from the prior custom RTP/depacketizer path.
 *  Does not modify the optical device or the installed Sytong Outdoor application.
 */
public final class MainActivity extends Activity {
    private static final String STREAM_PATH = "/h264/channel=0/video/";
    private static final String[] HOSTS = {"192.168.1.1", "192.168.1.254", "192.168.3.15"};
    private final Handler main = new Handler(Looper.getMainLooper());
    private PlayerView video;
    private TextView status, details;
    private Button connect, transport, record, files, fullscreen;
    private ExoPlayer player;
    private WifiManager.WifiLock wifiLock;
    private boolean connected = false, useTcp = false, immersive = false, rendered = false;
    private int generation = 0;
    private String host = HOSTS[0], lastDiagnostic = "";
    private long attemptStartMs = 0;
    private boolean wasBuffering = false;
    private int videoWidth = 0, videoHeight = 0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        makeUi();
        acquireWifiLock();
    }

    private void makeUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        video = new PlayerView(this);
        video.setUseController(false);
        video.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(video, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setPadding(dp(10), dp(6), dp(10), dp(6));
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setBackgroundColor(0xAD111111);
        status = label("HT70 • OFFLINE", 15);
        status.setTextColor(0xFF46EE83);
        details = label("MEDIA3 RTSP • v0.6 • UDP AUTO", 11);
        details.setGravity(Gravity.END);
        titleBar.addView(status, new LinearLayout.LayoutParams(0,-2,1));
        titleBar.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(titleBar,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.CENTER);
        buttons.setBackgroundColor(0xBA111111);
        buttons.setPadding(dp(4),dp(4),dp(4),dp(5));
        connect = button("CONNECT");
        transport = button("UDP AUTO");
        record = button("REC OFF");
        files = button("SD TEST");
        fullscreen = button("FULL");
        buttons.addView(connect); buttons.addView(transport);buttons.addView(record);buttons.addView(files);buttons.addView(fullscreen);
        root.addView(buttons,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        setContentView(root);

        // This diagnostic player is independent of the old raw-H.264 MP4 muxer.
        // Never advertise recording when there is no verified feed for that muxer.
        record.setEnabled(false);
        record.setAlpha(0.45f);
        connect.setOnClickListener(v -> { if(connected) disconnect(); else connect(); });
        transport.setOnClickListener(v -> {
            useTcp = !useTcp;
            transport.setText(useTcp ? "TCP FORCE" : "UDP AUTO");
            if(connected) openStream();
        });
        files.setOnClickListener(v -> {
            if(connected) disconnect();
            Intent i = new Intent(this,DeviceFilesActivity.class);
            i.putExtra("host",host);
            startActivity(i);
            Toast.makeText(this,"SD: yalnız HTTP diaqnostik test; orijinal fayl protokolu hələ tapılmayıb", Toast.LENGTH_LONG).show();
        });
        fullscreen.setOnClickListener(v -> {
            immersive = !immersive;
            getWindow().getDecorView().setSystemUiVisibility(immersive ?
                    View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY : 0);
            fullscreen.setText(immersive ? "EXIT FULL" : "FULL");
        });
        status.setOnLongClickListener(v -> {
            ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(
                    ClipData.newPlainText("HT70 diagnostics",lastDiagnostic));
            Toast.makeText(this,"Bağlantı diaqnostikası kopyalandı",Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void connect() {
        if(!bindToWifi()) {
            showStatus("HT70 • Wi-Fi TAPILMADI", "Öncə HT70 APPshow Wi-Fi-yə qoşulun");
            return;
        }
        connected = true;
        connect.setText("DISCONNECT");
        openStream();
    }

    private void openStream() {
        stopPlayer();
        final int myGen = ++generation;
        rendered = false;
        attemptStartMs = SystemClock.elapsedRealtime();
        wasBuffering = true;
        videoWidth = videoHeight = 0;
        host = HOSTS[0]; // Use the documented AP gateway first; alternate IPs need explicit device confirmation.
        String url = "rtsp://"+host+":554"+STREAM_PATH;
        String transportName=useTcp ? "TCP FORCE" : "UDP AUTO";
        showStatus("HT70 • RTSP BAĞLANIR", transportName+" • "+url);
        try {
            // Media3 provides well-tested RTSP/RTP packet handling, replacing the experimental client.
            RtspMediaSource.Factory rtsp = new RtspMediaSource.Factory()
                    .setForceUseRtpTcp(useTcp)
                    .setTimeoutMs(8000L);
            ExoPlayer created = new ExoPlayer.Builder(this).build();
            player = created;
            video.setPlayer(created);
            created.addListener(new Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if(myGen!=generation) return;
                    if(state==Player.STATE_BUFFERING){
                        wasBuffering=true;
                        showStatus(rendered?"HT70 • BUFFERING":"HT70 • AXIN GÖZLƏNİLİR",transportName+" • "+host);
                    } else if(state==Player.STATE_READY){
                        wasBuffering=false;
                        showStatus(rendered?"HT70 • CANLI":"HT70 • DEKODER HAZIR", transportName+" • "+host);
                    } else if(state==Player.STATE_ENDED){showStatus("HT70 • AXIN BİTDİ",transportName+" • yenidən qoşula bilərsiniz");}
                }
                @Override public void onRenderedFirstFrame(){
                    if(myGen!=generation)return;
                    rendered=true;
                    showStatus("HT70 • GÖRÜNTÜ VAR",transportName+" • "+videoWidth+"×"+videoHeight);
                }
                @Override public void onVideoSizeChanged(VideoSize size){
                    if(myGen!=generation)return;
                    videoWidth=size.width; videoHeight=size.height;
                    details.setText(transportName+" • "+videoWidth+"×"+videoHeight+" • "+host);
                }
                @Override public void onPlayerError(PlaybackException error){
                    if(myGen!=generation)return;
                    String why = error.getMessage()==null?error.getErrorCodeName():error.getMessage();
                    Throwable root=error;
                    while(root.getCause()!=null)root=root.getCause();
                    if(root!=error && root.getMessage()!=null)why=root.getClass().getSimpleName()+": "+root.getMessage();
                    showStatus("HT70 • RTSP XƏTASI",transportName+" • "+why);
                }
            });
            created.setMediaSource(rtsp.createMediaSource(MediaItem.fromUri(url)));
            created.prepare();
            created.play();
            main.postDelayed(() -> {
                if(connected && generation==myGen && !rendered)
                    showStatus("HT70 • KADR GƏLMƏDİ",transportName+" • 12s • başqa rejimi sınayın; statusu uzun basıb kopyalayın");
            },12000L);
        }catch(Exception ex){showStatus("HT70 • PLAYER XƏTASI",ex.getClass().getSimpleName()+": "+ex.getMessage());}
    }

    private void disconnect() {
        connected=false;
        ++generation;
        stopPlayer();
        connect.setText("CONNECT");
        showStatus("HT70 • OFFLINE","MEDIA3 RTSP • v0.6");
    }

    private void stopPlayer() {
        if(player!=null){
            video.setPlayer(null);
            try{player.release();}catch(Exception ignored){}
            player=null;
        }
    }

    private boolean bindToWifi() {
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            for(Network n:cm.getAllNetworks()){
                NetworkCapabilities caps=cm.getNetworkCapabilities(n);
                if(caps!=null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){
                    return cm.bindProcessToNetwork(n);
                }
            }
        }catch(Exception e){showStatus("HT70 • Wi-Fi ROUTE XƏTASI",String.valueOf(e.getMessage()));}
        return false;
    }

    private void showStatus(String left,String right) {
        status.setText(left);
        details.setText(right);
        lastDiagnostic="HT70 Vision Pro 0.6 | "+left+" | "+right;
    }

    private void acquireWifiLock(){
        try{
            WifiManager w=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiLock=w.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"HT70-v06");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        }catch(Exception ignored){}
    }

    private TextView label(String text,int size){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(Color.WHITE);v.setPadding(dp(4),dp(4),dp(4),dp(4));return v;}
    private Button button(String text){Button b=new Button(this);b.setText(text);b.setTextSize(11);b.setTextColor(Color.WHITE);b.setBackgroundColor(0xFF174D2A);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(49),1);p.setMargins(dp(3),0,dp(3),0);b.setLayoutParams(p);return b;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}

    @Override protected void onDestroy(){
        disconnect();
        try{((ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE)).bindProcessToNetwork(null);}catch(Exception ignored){}
        if(wifiLock!=null&&wifiLock.isHeld())wifiLock.release();
        super.onDestroy();
    }
}

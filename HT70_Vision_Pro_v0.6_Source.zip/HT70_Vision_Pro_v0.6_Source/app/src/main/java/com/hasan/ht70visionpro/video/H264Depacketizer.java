package com.hasan.ht70visionpro.video;

import com.hasan.ht70visionpro.net.RtpPacket;
import java.io.ByteArrayOutputStream;

/** RFC 6184 packetization modes: single NALU, STAP-A and FU-A. */
public final class H264Depacketizer {
    public interface Listener { void onAccessUnit(byte[] data, long rtpTimestamp, boolean keyFrame); }
    private final Listener listener;
    private final Runnable onCorrupted;
    private final ByteArrayOutputStream au = new ByteArrayOutputStream(256 * 1024);
    private long currentTs = -1;
    private boolean key, damaged, fuInProgress;

    public H264Depacketizer(Listener listener, Runnable onCorrupted) {
        this.listener = listener;
        this.onCorrupted = onCorrupted;
    }

    public void onPacket(RtpPacket p) {
        if (p.payload.length == 0) return;
        if (currentTs != -1 && p.timestamp != currentTs) {
            if (fuInProgress) damaged = true;
            emit();
        }
        currentTs = p.timestamp;
        int type = p.payload[0] & 0x1F;
        if (type >= 1 && type <= 23) {
            if (fuInProgress) damaged = true;
            fuInProgress = false;
            writeStartCode(); au.write(p.payload, 0, p.payload.length);
            if (type == 5) key = true;
        } else if (type == 24) {
            if (fuInProgress) damaged = true;
            fuInProgress = false;
            int pos = 1;
            while (pos + 2 <= p.payload.length) {
                int n = ((p.payload[pos] & 255) << 8) | (p.payload[pos + 1] & 255);
                pos += 2;
                if (n <= 0 || pos + n > p.payload.length) { damaged = true; break; }
                int nalType = p.payload[pos] & 0x1F;
                writeStartCode(); au.write(p.payload, pos, n);
                if (nalType == 5) key = true;
                pos += n;
            }
        } else if (type == 28) {
            if (p.payload.length < 2) { damaged = true; return; }
            int header = p.payload[1] & 255;
            boolean first = (header & 0x80) != 0, last = (header & 0x40) != 0;
            int originalType = header & 0x1F;
            if (first) {
                if (fuInProgress) damaged = true;
                writeStartCode();
                au.write((p.payload[0] & 0xE0) | originalType);
                fuInProgress = true;
                if (originalType == 5) key = true;
            } else if (!fuInProgress) {
                // A fragment without the beginning cannot reconstruct a NALU.
                damaged = true;
            }
            if (fuInProgress && p.payload.length > 2)
                au.write(p.payload, 2, p.payload.length - 2);
            if (last) fuInProgress = false;
        } else {
            // Unexpected packetization: do not feed arbitrary bytes to decoder.
            damaged = true;
        }
        if (au.size() > 4 * 1024 * 1024) damaged = true;
        if (p.marker) { if (fuInProgress) damaged = true; emit(); currentTs = -1; }
    }

    public void onPacketGap() { damaged = true; fuInProgress = false; onCorrupted.run(); }

    private void writeStartCode() { au.write(0); au.write(0); au.write(0); au.write(1); }

    private void emit() {
        if (!damaged && !fuInProgress && au.size() > 0)
            listener.onAccessUnit(au.toByteArray(), currentTs, key);
        else if (damaged) onCorrupted.run();
        au.reset(); key = false; damaged = false; fuInProgress = false;
    }
}

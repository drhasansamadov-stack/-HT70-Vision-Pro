package com.hasan.ht70visionpro.net;

import com.hasan.ht70visionpro.StreamStats;
import java.util.HashMap;
import java.util.Map;

/** Bounded, time-based RTP reordering buffer. Does NOT invent losses when no packets arrive. */
public final class AdaptiveJitterBuffer {
    private final Map<Integer, RtpPacket> packets = new HashMap<>();
    private final StreamStats stats;
    private int expected = -1;
    private long firstArrivalMs = -1;
    private long gapSinceMs = -1;
    private volatile int targetDelayMs = 180;
    private boolean started = false;

    public AdaptiveJitterBuffer(StreamStats stats) { this.stats = stats; }

    public synchronized void setTargetDelayMs(int ms) {
        targetDelayMs = Math.max(100, Math.min(450, ms));
        // Do not discard an entire buffered GOP merely because the mode changed.
    }

    public synchronized void reset() {
        packets.clear(); expected = -1; firstArrivalMs = -1; gapSinceMs = -1; started = false;
    }

    private static int forwardDistance(int from, int to) { return (to - from) & 0xFFFF; }

    public synchronized void offer(RtpPacket p) {
        stats.packets.incrementAndGet();
        stats.lastPacketAtMs = p.arrivalMs;
        if (expected < 0) { expected = p.sequence; firstArrivalMs = p.arrivalMs; }
        int dist = forwardDistance(expected, p.sequence);
        if (dist >= 0x8000) return; // An already-consumed/late packet.
        // Huge seq jump = camera reboot/stream restart, or stale backlog; resync.
        if (dist > 4096) {
            packets.clear(); expected = p.sequence; firstArrivalMs = p.arrivalMs;
            gapSinceMs = -1; started = false;
        }
        packets.putIfAbsent(p.sequence, p);
        if (packets.size() > 640) {
            packets.clear(); expected = p.sequence; firstArrivalMs = p.arrivalMs;
            gapSinceMs = -1; started = false;
            packets.put(p.sequence, p);
        }
    }

    public synchronized RtpPacket poll(long nowMs) {
        if (expected < 0) return null;
        if (!started) {
            if (nowMs - firstArrivalMs < targetDelayMs) return null;
            started = true;
        }
        RtpPacket result = packets.remove(expected);
        if (result != null) {
            expected = (expected + 1) & 0xFFFF;
            gapSinceMs = -1;
            return result;
        }
        // CRITICAL: when the stream pauses and the queue is empty, never
        // advance the sequence; that would turn later VALID packets into
        // 'late' packets, creating a self-perpetuating frozen picture.
        if (packets.isEmpty()) { gapSinceMs = -1; return null; }
        if (gapSinceMs < 0) gapSinceMs = nowMs;
        // Real evidence of a gap exists: at least one later packet is waiting.
        int maxWaitMs = Math.max(45, Math.min(130, targetDelayMs / 2));
        if (nowMs - gapSinceMs < maxWaitMs) return null;
        int nearest = -1; int distance = 0x8000;
        for (Integer seq : packets.keySet()) {
            int d = forwardDistance(expected, seq);
            if (d < distance) { distance = d; nearest = seq; }
        }
        if (nearest < 0) { gapSinceMs = -1; return null; }
        if (distance > 0) stats.lost.addAndGet(distance);
        expected = nearest;
        gapSinceMs = -1;
        RtpPacket p = packets.remove(expected);
        expected = (expected + 1) & 0xFFFF;
        return p;
    }
}

package com.hasan.ht70visionpro.net;

import java.util.Arrays;

public final class RtpPacket {
    public final int sequence;
    public final long timestamp;
    public final boolean marker;
    public final int payloadType;
    public final byte[] payload;
    public final long arrivalMs;

    private RtpPacket(int sequence, long timestamp, boolean marker, int payloadType, byte[] payload, long arrivalMs) {
        this.sequence = sequence;
        this.timestamp = timestamp;
        this.marker = marker;
        this.payloadType = payloadType;
        this.payload = payload;
        this.arrivalMs = arrivalMs;
    }

    public static RtpPacket parse(byte[] data, int length, long arrivalMs) {
        if (length < 12) return null;
        int v = (data[0] >> 6) & 0x03;
        if (v != 2) return null;
        boolean padding = (data[0] & 0x20) != 0;
        boolean extension = (data[0] & 0x10) != 0;
        int cc = data[0] & 0x0F;
        boolean marker = (data[1] & 0x80) != 0;
        int pt = data[1] & 0x7F;
        int seq = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
        long ts = ((long)(data[4] & 0xFF) << 24) | ((long)(data[5] & 0xFF) << 16)
                | ((long)(data[6] & 0xFF) << 8) | (data[7] & 0xFFL);
        int off = 12 + cc * 4;
        if (off > length) return null;
        if (extension) {
            if (off + 4 > length) return null;
            int words = ((data[off + 2] & 0xFF) << 8) | (data[off + 3] & 0xFF);
            off += 4 + words * 4;
            if (off > length) return null;
        }
        int end = length;
        if (padding) {
            int pad = data[length - 1] & 0xFF;
            if (pad > 0 && pad <= end - off) end -= pad;
        }
        if (end <= off) return null;
        return new RtpPacket(seq, ts, marker, pt, Arrays.copyOfRange(data, off, end), arrivalMs);
    }
}

# HT70 Vision Pro v0.6 — Media3 RTSP diagnostic player

**Status:** Android source prototype. Not yet built and not tested on HT70 hardware. This is a deliberate change of the *playback engine*, not a claim that the opticon hardware or transmission is fixed.

## Why this version

The uploaded v0.5 test video shows Wi-Fi connected to `APPshow-HT...` yet **zero video frames** and `SocketTimeoutException: Read timed out`. Both TCP Test and UDP modes show black screens. The v0.5 custom RTP/H.264 decoder may be too fragile and may wait indefinitely for an IDR keyframe. The TCP mode can acknowledge RTSP PLAY but never receive interleaved RTP packets.

## What's new

* Uses **AndroidX Media3 ExoPlayer RTSP** (`media3-exoplayer-rtsp`) for RTP parsing and H.264 decoding; it does not use the experimental Java RTP+MediaCodec pipeline from prior versions.
* `CONNECT` connects to the camera over the bound Wi-Fi network on `rtsp://192.168.1.1:554/h264/channel=0/video/`.
* `UDP AUTO` default, `TCP FORCE` optional. Try UDP first; TCP may be unsupported or silent on camera firmware.
* `FULL` immersive full display. `PlayerView` preserves aspect ratio to avoid distortion.
* Status differentiates RTSP connecting, buffering, first actually rendered frame, failure, and timeout. Long-press status to copy short diagnostics.
* Keeps independent Android application ID: `com.hasan.ht70visionpro`; it will not replace original Sytong Outdoor (`com.szsytong.sytong`).

## Intentional limitations

* **REC OFF**: disabled in v0.6 diagnostic mode because the previous recorder listens to a custom RTP source that this Media3 player does not expose. This prevents bogus claims that the phone recorded files.
* **SD TEST**: reuses the existing read-only HTTP diagnostic screen; it does **not** browse the manufacturer's real SD-card directory protocol. Do not mistake this for complete SD support.
* There is no bird/animal tracking or H.265 switch. Future work can follow once basic live view is reliable.
* Stream quality cannot exceed the camera's actual output. If Media3 renders the same mosaics as Sytong Outdoor, RF/camera encoder/firmware measurements will be necessary.

## Test plan

1. Install v0.6 and explicitly connect the phone to the HT70's `APPshow` Wi-Fi. Keep the original Sytong app closed. Do **not** change the optical firmware.
2. Open **HT70 Vision Pro**, leave `UDP AUTO` selected and tap `CONNECT`. Wait up to 12 seconds.
3. If you see video, compare quality and pauses with the original app at the same distance, preferably 1 meter; do not run both simultaneously.
4. If video stays black, long-press the status to copy the diagnostic message and send it. Then select `TCP FORCE` once and observe whether it renders a frame.
5. Compare a video recorded *by the optics itself* on its SD card to determine whether problems originate before the wireless transmission.

## GitHub build

Upload this ZIP at the repository root and replace the three `HT70_Vision_Pro_v0.5_Source` references in `.github/workflows/build-apk.yml` with `HT70_Vision_Pro_v0.6_Source`, commit. GitHub Actions then generates a debug APK. A successful build verifies compilation only.

This independent viewer is for lawful observation and general camera management, not aiming or ballistics.

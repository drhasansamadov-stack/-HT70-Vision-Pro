# HT70 Vision Pro — independent Android beta v0.2

This app has **its own** Android package ID `com.hasan.ht70visionpro`, launcher label, icon, private settings, and app-private photo folder. It does NOT update, replace, remove or access the private data of the original `com.szsytong.sytong` Sytong Outdoor app. It does not modify the HT70 firmware or camera settings. Both apps may be installed at the same time; only connect one to the HT70 live stream at once.

## Implemented in source (not device-validated)

- Read-only RTSP/H.264 RTP/UDP live view: `rtsp://192.168.1.1:554/h264/channel=0/video/`.
- Three jitter buffer presets, RTP loss/jitter/FPS metrics, hardware MediaCodec decoding, reconnection.
- Wi-Fi performance lock and app-process-only Wi-Fi binding.
- Live landscape view preserving the video aspect ratio; FULL button for immersive full-display view; single tap to show controls, double-tap to reset digital zoom, pinch to zoom.
- Phone-local JPEG snapshots in the application's separate Pictures/HT70VisionPro directory.

## Not yet implemented / not guaranteed

- Actual throughput improvements must be tested on the user's phone and camera: radio interference, device encoder rate and RTSP constraints can impose hard limits.
- Downloading videos/photos from HT70 device, saving live MP4, H.265, movement detection, and user-specified notification sounds are **not yet implemented**. No automatic aiming, reticle control or ballistic targeting functionality.
- RTSP endpoint derived from prior examination of firmware and user-supplied original app; live protocol/device connectivity not tested.

## Build

The project is Android Java and Gradle. Push the **contents** of this folder to a NEW GitHub repository (e.g. `HT70-Vision-Pro`), open Actions -> `Build HT70 Vision Pro APK` -> Run workflow, download `HT70-Vision-Pro-v0.2-debug-apk` from Artifacts. The resulting debug APK is independently installable after Android allows installation from the source app. The hosted Actions build itself needs verification. No signed release is included in this ZIP.

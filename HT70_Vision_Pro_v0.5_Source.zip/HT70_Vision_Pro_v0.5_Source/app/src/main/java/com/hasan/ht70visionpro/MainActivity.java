package com.hasan.ht70visionpro;

import android.app.Activity;
import android.content.Intent;
import com.hasan.ht70visionpro.files.DeviceFilesActivity;
import com.hasan.ht70visionpro.video.OriginalStreamRecorder;
import android.content.Context;
import android.graphics.*;
import android.net.*;
import android.net.wifi.WifiManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.hasan.ht70visionpro.net.RtspUdpClient;
import com.hasan.ht70visionpro.video.AvcDecoder;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity implements TextureView.SurfaceTextureListener {
    private TextureView video; private TextView hud,status; private Button connect,mode,record,files,full;
    private LinearLayout topBar,bottomBar; private boolean immersive=false; private boolean overlaysVisible=true;
    private GestureDetector gestures; private volatile boolean userWantsConnection=false;
    private RtspUdpClient client; private AvcDecoder decoder; private OriginalStreamRecorder recorder; private final StreamStats stats=new StreamStats();
    private String lastConnectedHost="192.168.1.1";
    private Surface surface; private WifiManager.WifiLock wifiLock; private final Handler ui=new Handler(Looper.getMainLooper());
    private int bufferMode=1; private int videoW=16,videoH=9; private float zoom=1f; private ScaleGestureDetector scale;
    private byte[] pendingSps,pendingPps; private int pendingW=1920,pendingH=1080;
    private final String[] hosts={"192.168.1.1","192.168.1.254","192.168.3.15"};
    private long lastFrameCount=0,stallStarted=0;
    private int tcpTest=0; // 0 UDP, 1 experimental RTSP/TCP test
    private long lastRecoveryAt=0;

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); getWindow().setStatusBarColor(Color.BLACK); recorder=new OriginalStreamRecorder(this,(msg,success)->ui.post(()->{record.setText("REC");record.setEnabled(true);record.setBackgroundColor(0xFF174D2A);toast(msg);status.setText(msg);})); buildUi(); acquireWifi(); bindWifiIfActive(); ui.post(statsLoop);}

    private void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        video=new TextureView(this); video.setSurfaceTextureListener(this); root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this); topBar=top; top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(10),dp(6),dp(10),dp(6));top.setBackgroundColor(0x990B0B0B);
        status=txt("HT70 • OFFLINE",16); status.setTextColor(0xFF35E06F);top.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        hud=txt("",12);hud.setGravity(Gravity.END);top.addView(hud,new LinearLayout.LayoutParams(0,-2,1));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);root.addView(top,tp);
        LinearLayout bar=new LinearLayout(this); bottomBar=bar; bar.setGravity(Gravity.CENTER);bar.setPadding(dp(8),dp(6),dp(8),dp(8));bar.setBackgroundColor(0xAA101010);
        connect=btn("CONNECT");mode=btn("BALANCED");record=btn("REC");files=btn("SD FILES");full=btn("FULL");bar.addView(connect);bar.addView(mode);bar.addView(record);bar.addView(files);bar.addView(full);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);root.addView(bar,bp);setContentView(root);
        connect.setOnClickListener(v->{if(client==null)connect();else disconnect();}); mode.setOnClickListener(v->cycleMode()); record.setOnClickListener(v->toggleRecording());files.setOnClickListener(v->openSdFiles());full.setOnClickListener(v->toggleFullscreen());
        scale=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){zoom*=d.getScaleFactor();zoom=Math.max(1f,Math.min(4f,zoom));applyTransform();return true;}});
        gestures=new GestureDetector(this,new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onDown(MotionEvent e){return true;}
            @Override public boolean onSingleTapConfirmed(MotionEvent e){if(immersive){overlaysVisible=!overlaysVisible;setOverlayVisibility();}return true;}
            @Override public boolean onDoubleTap(MotionEvent e){zoom=1f;applyTransform();return true;}
        });
        video.setOnTouchListener((v,e)->{scale.onTouchEvent(e);gestures.onTouchEvent(e);return true;});
    }

    private void connect(){ bindWifiIfActive(); userWantsConnection=true; if(surface==null){toast("Video səthi hazır deyil");return;} connect.setEnabled(false); status.setText("HT70 • AXTARILIR…"); new Thread(()->probeAndStart(),"HT70-Probe").start(); }
    private void probeAndStart(){
        String host=null; for(String h:hosts){try{java.net.Socket s=new java.net.Socket();s.connect(new java.net.InetSocketAddress(h,554),450);s.close();host=h;break;}catch(Exception ignored){}}
        final String found=host; ui.post(()->{if(!userWantsConnection)return;connect.setEnabled(true);if(found==null){status.setText("HT70 • TAPILMADI");toast("Telefonu HT70 Wi‑Fi şəbəkəsinə qoşun");return;}startClient(found);});
    }
    private void startClient(String host){
        lastConnectedHost=host;disconnectInternal(); status.setText("HT70 • "+host+" • CONNECTING");
        client=new RtspUdpClient(host,554,"/h264/channel=0/video/",new RtspUdpClient.Callback(){
            public void onStatus(String s){ui.post(()->{status.setText("HT70 • "+s);connect.setText("DISCONNECT");});}
            public void onVideoConfig(byte[]sps,byte[]pps,int w,int h){recorder.setVideoFormat(sps,pps,w,h);pendingSps=sps;pendingPps=pps;pendingW=w;pendingH=h;videoW=w;videoH=h;ui.post(()->{applyTransform();try{decoder=new AvcDecoder(surface,stats);decoder.start(w,h,sps,pps);}catch(Exception e){status.setText("DECODER ERROR: "+e.getMessage());}});}
            public void onAccessUnit(byte[]data,long ts,boolean key){recorder.learnParameterSets(data);recorder.offer(data,ts,key);AvcDecoder d=decoder;if(d!=null)d.queue(data,ts,key);}
            public void onCorruptedFrame(){AvcDecoder d=decoder;if(d!=null)d.dropUntilKeyframe();}
            public void onFatal(String reason){ui.post(()->{if(!userWantsConnection)return;status.setText("HT70 • LINK LOST • "+reason);stats.reconnects.incrementAndGet();disconnectInternal();ui.postDelayed(()->{if(userWantsConnection && surface!=null && client==null)connect();},900);});}
        },stats);
        client.setTcpMode(bufferMode==3);client.setBufferMs(currentBuffer()); client.start();
    }
    private void disconnect(){userWantsConnection=false;disconnectInternal();status.setText("HT70 • OFFLINE");connect.setText("CONNECT");}
    private void disconnectInternal(){if(recorder!=null)recorder.stop();RtspUdpClient c=client;client=null;if(c!=null)c.stop();if(decoder!=null){decoder.stop();decoder=null;}}
    private int currentBuffer(){return bufferMode==0?120:bufferMode==1?180:bufferMode==2?330:180;}
    private void toggleFullscreen(){
        immersive=!immersive;overlaysVisible=!immersive;setOverlayVisibility();
        int flags=immersive?(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE):0;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        if(!immersive)full.setText("FULL");
    }
    private void setOverlayVisibility(){
        topBar.setVisibility(overlaysVisible?View.VISIBLE:View.GONE);
        bottomBar.setVisibility(overlaysVisible?View.VISIBLE:View.GONE);
        full.setText(immersive?"EXIT FULL":"FULL");
    }
    private void cycleMode(){
        int previous=bufferMode;
        bufferMode=(bufferMode+1)%4;
        String[] names={"LOW LATENCY","BALANCED","STABLE","TCP TEST"};
        mode.setText(names[bufferMode]);
        if(client!=null){
            if(previous==3||bufferMode==3){
                toast("Şəbəkə protokolu dəyişir; yenidən qoşulur…");
                startClient(lastConnectedHost);
            }else client.setBufferMs(currentBuffer());
        }
    }

    private void applyTransform(){ if(video.getWidth()==0||video.getHeight()==0)return; float vw=video.getWidth(),vh=video.getHeight();float ar=(float)videoW/videoH;float view=vw/vh;float sx=1,sy=1;if(ar>view)sy=view/ar;else sx=ar/view;Matrix m=new Matrix();m.setScale(sx*zoom,sy*zoom,vw/2f,vh/2f);video.setTransform(m);}
    private void toggleRecording(){
        if(recorder==null)return;
        if(recorder.isRecording()){
            recorder.stop();record.setText("SAVING…");record.setEnabled(false);
            toast("MP4 yekunlaşdırılır…");
            return;
        }
        if(client==null || stats.lastFrameAtMs==0 || System.currentTimeMillis()-stats.lastFrameAtMs>3500){
            toast("Canlı FPS yoxdur; video yazmaq mümkün deyil. Əvvəl görüntünü sabitləşdirin.");return;
        }
        String error=recorder.start();
        if(error!=null){toast(error);return;}
        record.setText("STOP REC");record.setBackgroundColor(0xFFAD1622);
        toast("REC başladı — IDR açar kadr gözlənilir; sonra Movies/HT70VisionPro-yə yazılacaq");
    }

    private void openSdFiles(){
        if(recorder!=null && recorder.isBusy()){
            toast("Əvvəl STOP REC seçin və MP4 tamamlanmasını gözləyin");return;
        }
        // Avoid two heavy simultaneous transfers over the camera's narrow Wi-Fi.
        userWantsConnection=false;disconnectInternal();connect.setText("CONNECT");bindWifiIfActive();
        Intent i=new Intent(this,DeviceFilesActivity.class);i.putExtra("host",lastConnectedHost);startActivity(i);
    }

    private void acquireWifi(){try{WifiManager wm=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);wifiLock=wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"HT70VisionPro");wifiLock.setReferenceCounted(false);wifiLock.acquire();}catch(Exception ignored){}}
    private void bindWifiIfActive(){
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            // The camera AP has no Internet, so Android may report mobile data as active.
            // Find the Wi-Fi network independently of the default Internet route.
            for(Network n:cm.getAllNetworks()){
                NetworkCapabilities caps=cm.getNetworkCapabilities(n);
                if(caps!=null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){
                    cm.bindProcessToNetwork(n);return;
                }
            }
        }catch(Exception e){status.setText("Wi-Fi route: "+e.getMessage());}
    }

    private final Runnable statsLoop=new Runnable(){public void run(){
        long now=System.currentTimeMillis(),total=stats.frames.get();
        if(total!=lastFrameCount){lastFrameCount=total;stallStarted=0;}
        else if(client!=null && stats.lastPacketAtMs>0 && now-stats.lastPacketAtMs<1300){
            if(stallStarted==0)stallStarted=now;
            if(now-stallStarted>5000 && now-lastRecoveryAt>9000){
                lastRecoveryAt=now;stallStarted=0;
                if(bufferMode==0){
                    bufferMode=1;mode.setText("BALANCED");
                    toast("LOW LATENCY dondu: BALANCED rejiminə qayıdır");
                }
                status.setText("HT70 • Görüntü dayanıb; RTSP yenidən qoşulur…");
                startClient(lastConnectedHost);
            }
        } else stallStarted=0;
        String recInfo="";
        if(recorder!=null && recorder.isRecording()){
            recInfo=recorder.isWaitingForKeyFrame()?" • REC: WAIT IDR":" • REC "+recorder.getSavedFrames()+"f";
        }
        String decErr=stats.decoderError.isEmpty()?"":" • DEC ERR";
        hud.setText(String.format(Locale.US,"FPS %.1f LOSS %.2f%% JIT %.1fms BUF %dms%s%s",stats.fps,stats.lossPercent(),stats.jitterMs,currentBuffer(),recInfo,decErr));
        ui.postDelayed(this,500);
    }};
    private TextView txt(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.WHITE);t.setPadding(dp(6),dp(4),dp(6),dp(4));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setBackgroundColor(0xFF174D2A);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.setMargins(dp(5),0,dp(5),0);b.setLayoutParams(p);return b;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){surface=new Surface(st);applyTransform();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){applyTransform();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){disconnectInternal();if(surface!=null){surface.release();surface=null;}return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture st){}
    @Override protected void onDestroy(){userWantsConnection=false;disconnectInternal();try{((ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).bindProcessToNetwork(null);}catch(Exception ignored){}ui.removeCallbacks(statsLoop);if(wifiLock!=null&&wifiLock.isHeld())wifiLock.release();super.onDestroy();}
}

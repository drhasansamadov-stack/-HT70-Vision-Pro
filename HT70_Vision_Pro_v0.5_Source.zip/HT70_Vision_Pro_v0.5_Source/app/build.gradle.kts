plugins { id("com.android.application") }

android {
    namespace = "com.hasan.ht70visionpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hasan.ht70visionpro"
        minSdk = 24
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0-stream-recovery"
    }
}

# HT70 Vision Pro v0.5 — Stream recovery test

**Independent Android application**: `com.hasan.ht70visionpro` (does not replace Sytong Outdoor).

## What changed relative to v0.4

1. RTP jitter buffer no longer invents packet loss during a network pause (no queued future packets), a defect that previously advanced the expected sequence and could discard subsequently valid packets.
2. Actual sequence gaps are handled only when newer packets have arrived. The buffer skips to the nearest available sequence after waiting rather than chasing nonexistent packets indefinitely.
3. H.264 FU-A fragments are validated: incomplete packets are dropped, not fed into the decoder.
4. On corrupted data, the decoder waits for an intact IDR keyframe to avoid displaying dependent damaged P-frames. Video may momentarily freeze while waiting for an IDR; this favors a clean frame over mosaic artifacts.
5. Buffer choices now favor stability: Low Latency 120 ms / Balanced 180 ms / Stable 330 ms / TCP Test 180 ms. **Actual latency may be higher**.

## Still unverified / not fixed

- Wi-Fi stability and source bit rate are limited by the HT70 firmware and RF environment. v0.5 has **not** been verified on the physical camera.
- No assurance of higher FPS or H.265. The optical device's own RTSP stream caps both.
- **SD card browsing/download remains unsupported** until Sytong's control/data protocol is verified. Existing HTTP probes remain diagnostic-only.
- REC still needs valid SPS/PPS and a clean IDR keyframe; insufficient RTSP video may prevent saving a usable MP4.
- This version prioritizes stabilization, not bird/animal tracking or ballistic capabilities.

## Build

Upload `HT70_Vision_Pro_v0.5_Source.zip` to the same GitHub repository. Edit `.github/workflows/build-apk.yml` by replacing the **three** `v0.3` references with `v0.5`, commit, and download the debug APK from successful Actions artifacts. Use the physical camera only after successful compilation. Debug APK signing keys may differ across GitHub runs; if install fails with signature mismatch, uninstall only the old HT70 Vision Pro experimental app (not Sytong Outdoor) and reinstall.

## Diagnostic test

1. Put phone within 1–2 m of HT70, keep original Sytong app closed. Disable battery restrictions for test, select Balanced.
2. Test 30–60 seconds in Balanced then Stable. Note actual FPS, visible mosaics, Wi-Fi signal and any reconnects.
3. Compare original Sytong Outdoor in same position and exact scene. Do not run both simultaneously.
4. Record an actual video onto the HT70 SD card using its hardware controls. Inspect local recording to distinguish capture issues from Wi-Fi streaming issues.
